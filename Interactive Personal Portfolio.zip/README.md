
  # Interactive Personal Portfolio

  This is a code bundle for Interactive Personal Portfolio. The original project is available at https://www.figma.com/design/kg8w4BRzjB4pX2laKfBiGt/Interactive-Personal-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  