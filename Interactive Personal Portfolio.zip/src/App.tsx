import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { TechnicalArsenalSection } from './components/TechnicalArsenalSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ContactSection } from './components/ContactSection';
import { AIAssistant } from './components/AIAssistant';
import { CustomCursor } from './components/CustomCursor';
import { ThemeToggle } from './components/ThemeToggle';
import { PacManAnimation } from './components/PacManAnimation';
import { DateTime } from './components/DateTime';

export default function App() {
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    // Initialize with dark mode
    document.documentElement.classList.add('dark');
  }, []);

  const handleThemeChange = (isDark: boolean) => {
    setIsDarkMode(isDark);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className={`min-h-screen transition-colors duration-500 ${
          isDarkMode 
            ? 'bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white' 
            : 'bg-white text-gray-900'
        }`}
      >
        {/* Background Effects */}
        <div className="fixed inset-0 z-0">
          {/* Animated gradient orbs - only show in dark mode */}
          {isDarkMode && (
            <>
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                  x: [0, 50, 0],
                  y: [0, -30, 0]
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl bg-gradient-to-r from-green-500/20 to-cyan-500/20"
              />
              <motion.div
                animate={{
                  scale: [1.2, 1, 1.2],
                  opacity: [0.4, 0.6, 0.4],
                  x: [0, -40, 0],
                  y: [0, 20, 0]
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 2
                }}
                className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full blur-3xl bg-gradient-to-r from-blue-500/20 to-purple-500/20"
              />
              <motion.div
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.2, 0.4, 0.2],
                  rotate: [0, 180, 360]
                }}
                transition={{
                  duration: 15,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 4
                }}
                className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full blur-3xl bg-gradient-to-r from-cyan-500/20 to-green-500/20"
              />
            </>
          )}
        </div>

        {/* Content */}
        <div className="relative z-10">
          {/* Real-time Date & Time */}
          <DateTime isDarkMode={isDarkMode} />
          
          <Navigation />
          
          <main>
            <section id="home">
              <HeroSection />
            </section>
            
            <AboutSection />
            <TechnicalArsenalSection isDarkMode={isDarkMode} />
            <ProjectsSection />
            <ContactSection />
            
            {/* Pac-Man Animation - Playful Footer Element */}
            <PacManAnimation isDarkMode={isDarkMode} />
          </main>

          {/* Footer */}
          <motion.footer
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className={`py-16 px-4 border-t ${
              isDarkMode 
                ? 'border-gray-700/50 bg-gray-900/30 backdrop-blur-sm' 
                : 'border-gray-200 bg-gray-50'
            }`}
          >
            <div className="max-w-6xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                {/* Brand */}
                <div className="text-center md:text-left">
                  <h3 className={`text-xl mb-4 ${
                    isDarkMode 
                      ? 'bg-gradient-to-r from-cyan-400 to-yellow-400 bg-clip-text text-transparent'
                      : 'text-gray-800'
                  }`}>
                    Building Tomorrow's Technology
                  </h3>
                  <p className={`text-sm ${
                    isDarkMode ? 'text-gray-400' : 'text-gray-600'
                  }`}>
                    Passionate about creating innovative solutions that make a difference.
                  </p>
                </div>

                {/* Quick Links */}
                <div className="text-center">
                  <h4 className={`mb-4 ${
                    isDarkMode ? 'text-white' : 'text-gray-800'
                  }`}>Quick Links</h4>
                  <div className="space-y-2">
                    <a href="#home" className={`block transition-colors duration-300 text-sm ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-cyan-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>Home</a>
                    <a href="#about" className={`block transition-colors duration-300 text-sm ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-cyan-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>About</a>
                    <a href="#skills" className={`block transition-colors duration-300 text-sm ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-cyan-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>Skills</a>
                    <a href="#projects" className={`block transition-colors duration-300 text-sm ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-cyan-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>Projects</a>
                    <a href="#contact" className={`block transition-colors duration-300 text-sm ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-cyan-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>Contact</a>
                  </div>
                </div>

                {/* Social Media */}
                <div className="text-center md:text-right">
                  <h4 className={`mb-4 ${
                    isDarkMode ? 'text-white' : 'text-gray-800'
                  }`}>Connect</h4>
                  <div className="flex justify-center md:justify-end gap-4">
                    <a href="https://github.com/sadiapeerzada" target="_blank" rel="noopener noreferrer" className={`transition-colors duration-300 ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-purple-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>
                      GitHub
                    </a>
                    <a href="https://linkedin.com/in/sadia-peerzada" target="_blank" rel="noopener noreferrer" className={`transition-colors duration-300 ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-blue-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>
                      LinkedIn
                    </a>
                    <a href="https://instagram.com/sadia.peerzada" target="_blank" rel="noopener noreferrer" className={`transition-colors duration-300 ${
                      isDarkMode 
                        ? 'text-gray-400 hover:text-pink-400' 
                        : 'text-gray-600 hover:text-gray-800'
                    }`}>
                      Instagram
                    </a>
                  </div>
                </div>
              </div>

              <div className={`border-t pt-8 text-center ${
                isDarkMode ? 'border-gray-700/50' : 'border-gray-200'
              }`}>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                  viewport={{ once: true }}
                  className="mb-6"
                >
                  <p className={`mb-2 ${
                    isDarkMode ? 'text-gray-300' : 'text-gray-700'
                  }`}>
                    Built with React, Tailwind CSS, and Motion
                  </p>
                  <p className={`text-sm ${
                    isDarkMode ? 'text-gray-400' : 'text-gray-600'
                  }`}>
                    Brought to you by Sadia Peerzada © 2025. All rights reserved.
                  </p>
                </motion.div>
                
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${
                    isDarkMode 
                      ? 'bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/20'
                      : 'bg-gray-100 border border-gray-300'
                  }`}>
                    <span className={`w-2 h-2 rounded-full animate-pulse ${
                      isDarkMode ? 'bg-green-400' : 'bg-green-500'
                    }`}></span>
                    <span className={`text-sm ${
                      isDarkMode ? 'text-gray-300' : 'text-gray-700'
                    }`}>Available for opportunities</span>
                  </div>
                </motion.div>
              </div>
            </div>
          </motion.footer>

          {/* AI Assistant */}
          <AIAssistant />
          
          {/* Theme Toggle */}
          <ThemeToggle onThemeChange={handleThemeChange} />
          
          {/* Custom Cursor */}
          <CustomCursor />
        </div>
      </motion.div>
    </>
  );
}