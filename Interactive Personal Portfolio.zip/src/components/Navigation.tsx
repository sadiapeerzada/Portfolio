import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Menu, X } from 'lucide-react';

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);

      // Update active section based on scroll position
      const sections = ['home', 'about', 'skills', 'projects', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;
          
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { label: 'Home', href: '#home', id: 'home' },
    { label: 'About', href: '#about', id: 'about' },
    { label: 'Skills', href: '#skills', id: 'skills' },
    { label: 'Projects', href: '#projects', id: 'projects' },
    { label: 'Contact', href: '#contact', id: 'contact' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setIsOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled 
          ? 'bg-gray-900/95 dark:bg-gray-900/95 bg-white/95 backdrop-blur-xl border-b border-gray-700/50 dark:border-gray-700/50 border-gray-300/50 shadow-2xl' 
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <a 
              href="#home" 
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#home');
              }}
              className="text-2xl text-white dark:text-white text-gray-900 hover:text-cyan-400 transition-colors duration-300 font-bold"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Sadia<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">.</span>
            </a>
          </motion.div>

          {/* Desktop Menu */}
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="hidden md:flex items-center space-x-10"
          >
            {menuItems.map((item, index) => (
              <motion.a
                key={item.label}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(item.href);
                }}
                initial={{ opacity: 0, y: -30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 + index * 0.1 }}
                className={`relative group transition-all duration-300 font-medium ${
                  activeSection === item.id
                    ? 'text-cyan-400'
                    : 'text-gray-300 dark:text-gray-300 text-gray-700 hover:text-cyan-400'
                }`}
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                {item.label}
                <motion.span 
                  className={`absolute -bottom-2 left-0 h-0.5 bg-gradient-to-r from-cyan-400 to-blue-400 transition-all duration-300 ${
                    activeSection === item.id ? 'w-full' : 'w-0 group-hover:w-full'
                  }`}
                ></motion.span>
              </motion.a>
            ))}
          </motion.div>

          {/* Mobile Menu Button */}
          <div className="flex items-center">
            <motion.button
              initial={{ opacity: 0, scale: 0.7 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              onClick={() => setIsOpen(!isOpen)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="md:hidden p-3 rounded-xl bg-gray-800/60 dark:bg-gray-800/60 bg-gray-200/60 text-gray-300 dark:text-gray-300 text-gray-700 hover:text-cyan-400 hover:bg-gray-700/60 dark:hover:bg-gray-700/60 hover:bg-gray-300/60 transition-all duration-300 backdrop-blur-sm border border-gray-600/30 dark:border-gray-600/30 border-gray-400/30"
            >
              <motion.div
                animate={{ rotate: isOpen ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                {isOpen ? <X size={24} /> : <Menu size={24} />}
              </motion.div>
            </motion.button>
          </div>
        </div>

        {/* Mobile Menu */}
        <motion.div
          initial={{ opacity: 0, height: 0, y: -20 }}
          animate={{ 
            opacity: isOpen ? 1 : 0, 
            height: isOpen ? 'auto' : 0,
            y: isOpen ? 0 : -20
          }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="md:hidden overflow-hidden"
        >
          <div className="py-6 space-y-2 bg-gray-900/95 dark:bg-gray-900/95 bg-white/95 backdrop-blur-xl rounded-2xl mt-4 border border-gray-700/50 dark:border-gray-700/50 border-gray-300/50 shadow-2xl">
            {menuItems.map((item, index) => (
              <motion.a
                key={item.label}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(item.href);
                }}
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: isOpen ? 1 : 0, x: isOpen ? 0 : -30 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className={`block px-6 py-3 mx-2 rounded-xl transition-all duration-300 font-medium ${
                  activeSection === item.id
                    ? 'text-cyan-400 bg-cyan-400/10 border border-cyan-400/30'
                    : 'text-gray-300 hover:text-cyan-400 hover:bg-gray-800/60'
                }`}
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                {item.label}
              </motion.a>
            ))}
          </div>
        </motion.div>
      </div>
    </motion.nav>
  );
}