import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import profileImage from 'figma:asset/8945bd12f991fd533bdb10dd5c02961634408565.png';

const roles = [
  { text: "Student", color: "text-yellow-400" },
  { text: "Developer", color: "text-blue-400" },
  { text: "Coder", color: "text-pink-400" }
];

export function HeroSection() {
  const [currentRole, setCurrentRole] = useState(0);
  const [displayText, setDisplayText] = useState("");
  const [isTyping, setIsTyping] = useState(true);

  useEffect(() => {
    const currentRoleText = roles[currentRole].text;
    let index = 0;

    if (isTyping) {
      const typingInterval = setInterval(() => {
        if (index <= currentRoleText.length) {
          setDisplayText(currentRoleText.slice(0, index));
          index++;
        } else {
          setIsTyping(false);
          setTimeout(() => {
            setIsTyping(false);
            setTimeout(() => {
              setCurrentRole((prev) => (prev + 1) % roles.length);
              setDisplayText("");
              setIsTyping(true);
            }, 1000);
          }, 2000);
          clearInterval(typingInterval);
        }
      }, 150);

      return () => clearInterval(typingInterval);
    }
  }, [currentRole, isTyping]);

  return (
    <section className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      {/* Animated background grid */}
      <div className="absolute inset-0 opacity-10">
        <div className="grid-background"></div>
      </div>
      
      {/* Floating particles */}
      <div className="absolute inset-0">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className="text-center max-w-4xl mx-auto relative z-10"
      >
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="mb-8"
        >
          <div className="relative mb-8">
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
                rotate: [0, 1, -1, 0]
              }}
              transition={{
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative"
            >
              <motion.img
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1, delay: 0.2 }}
                src={profileImage}
                alt="Sadia Peerzada"
                className="w-48 h-48 rounded-full mx-auto object-cover border-4 border-cyan-400/50 shadow-lg shadow-cyan-400/25"
              />
              <div className="absolute inset-0 w-48 h-48 rounded-full mx-auto bg-gradient-to-tr from-green-400/20 to-blue-400/20"></div>
              <div 
                className="absolute inset-0 w-48 h-48 rounded-full mx-auto border-4 border-transparent bg-gradient-to-tr from-green-400 via-cyan-400 to-blue-400 animate-pulse" 
                style={{ 
                  padding: '2px', 
                  WebkitMask: 'radial-gradient(circle, transparent 46%, black 48%)',
                  mask: 'radial-gradient(circle, transparent 46%, black 48%)'
                }}
              ></div>
            </motion.div>
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 50, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.4, type: "spring", stiffness: 100 }}
          className="text-5xl md:text-7xl mb-8 bg-gradient-to-r from-white via-cyan-200 to-blue-200 bg-clip-text text-transparent"
        >
          Hi, I'm Sadia Peerzada
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="text-2xl md:text-4xl h-16 flex items-center justify-center mb-8"
        >
          <span className="text-white mr-3">I am a </span>
          <span className={`${roles[currentRole].color} min-w-[200px] text-left`}>
            {displayText}
            <span className="animate-pulse">|</span>
          </span>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="text-lg text-gray-300 max-w-3xl mx-auto mt-8 leading-relaxed"
        >
          BCA 2nd Year Student | Passionate about Exploring Technology, Building Software Solutions, and Creating Innovative Projects.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.4 }}
          className="mt-12"
        >
          <motion.button 
            onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
            className="px-8 py-4 bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-lg hover:shadow-lg hover:shadow-green-400/25 transition-all duration-300 transform hover:scale-105"
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 10px 30px rgba(34, 197, 94, 0.3)"
            }}
            whileTap={{ scale: 0.95 }}
            animate={{
              boxShadow: [
                "0 0 20px rgba(34, 197, 94, 0.2)",
                "0 0 30px rgba(59, 130, 246, 0.2)",
                "0 0 20px rgba(34, 197, 94, 0.2)"
              ]
            }}
            transition={{ 
              boxShadow: { duration: 3, repeat: Infinity },
              scale: { duration: 0.2 }
            }}
          >
            Explore My Journey
          </motion.button>
        </motion.div>
      </motion.div>

      <style>{`
        .grid-background {
          background-image: 
            linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px);
          background-size: 50px 50px;
          width: 100%;
          height: 100%;
          animation: gridMove 20s linear infinite;
        }
        
        @keyframes gridMove {
          0% { transform: translate(0, 0); }
          100% { transform: translate(50px, 50px); }
        }
      `}</style>
    </section>
  );
}