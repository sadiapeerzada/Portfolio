import { motion } from 'motion/react';
import { Github, Linkedin, Instagram, Mail, Send } from 'lucide-react';
import { useState } from 'react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";

const socialLinks = [
  {
    name: "GitHub",
    icon: Github,
    url: "https://github.com",
    color: "hover:text-purple-400 hover:shadow-purple-400/25",
    description: "Check out my code"
  },
  {
    name: "LinkedIn",
    icon: Linkedin,
    url: "https://linkedin.com",
    color: "hover:text-blue-400 hover:shadow-blue-400/25",
    description: "Professional network"
  },
  {
    name: "Instagram",
    icon: Instagram,
    url: "https://instagram.com",
    color: "hover:text-pink-400 hover:shadow-pink-400/25",
    description: "Photography & life"
  }
];

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section className="py-20 px-4" id="contact">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-8 bg-gradient-to-r from-yellow-400 to-green-400 bg-clip-text text-transparent leading-tight py-2">
            Let's Work Together
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-yellow-400 to-green-400 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8">
              <h3 className="text-2xl mb-6 text-white">Get in Touch</h3>
              <div className="space-y-6">
                <p className="text-gray-300 leading-relaxed">
                  Have a project in mind? Let's discuss how we can bring your ideas to life. 
                  I'm always excited to work on innovative projects and collaborate with like-minded individuals.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  Whether you have a startup idea, need technical consultation, or want to discuss emerging technologies — I'd love to hear from you.
                </p>
              </div>

              {/* Email Contact */}
              <div className="mt-8 p-6 bg-gradient-to-r from-gray-800/50 to-gray-700/50 rounded-xl border border-gray-600/30">
                <div className="flex items-center gap-3 mb-2">
                  <Mail className="w-5 h-5 text-green-400" />
                  <span className="text-white">Email</span>
                </div>
                <a 
                  href="mailto:sadiapeerzada2006@gmail.com"
                  className="text-green-400 hover:text-green-300 transition-colors duration-300"
                >
                  sadiapeerzada2006@gmail.com
                </a>
              </div>

              {/* Social Links */}
              <div className="mt-8">
                <h4 className="text-white mb-4">Connect with me</h4>
                <div className="flex gap-4">
                  {socialLinks.map((link, index) => {
                    const IconComponent = link.icon;
                    return (
                      <motion.a
                        key={link.name}
                        href={link.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        initial={{ opacity: 0, scale: 0.8 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.6, delay: index * 0.1 }}
                        viewport={{ once: true }}
                        className={`flex items-center justify-center w-12 h-12 bg-gray-800/50 rounded-xl border border-gray-600/50 transition-all duration-300 ${link.color} hover:scale-110 hover:border-current/50`}
                      >
                        <IconComponent className="w-5 h-5 text-gray-400 group-hover:text-current transition-colors duration-300" />
                      </motion.a>
                    );
                  })}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8">
              <h3 className="text-2xl mb-6 text-white">Send a Message</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm text-gray-300 mb-2">
                    Name
                  </label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-gray-800/50 border-gray-600/50 text-white placeholder-gray-400 focus:border-cyan-400/50"
                    placeholder="Your name"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm text-gray-300 mb-2">
                    Email
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-gray-800/50 border-gray-600/50 text-white placeholder-gray-400 focus:border-cyan-400/50"
                    placeholder="name@example.com"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm text-gray-300 mb-2">
                    What's this about?
                  </label>
                  <Input
                    id="subject"
                    name="subject"
                    type="text"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full bg-gray-800/50 border-gray-600/50 text-white placeholder-gray-400 focus:border-cyan-400/50"
                    placeholder="Project collaboration, consultation, etc."
                    required
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm text-gray-300 mb-2">
                    Tell me about your project/idea
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full bg-gray-800/50 border-gray-600/50 text-white placeholder-gray-400 focus:border-cyan-400/50 min-h-[120px] resize-none"
                    placeholder="Describe your project, goals, timeline, or any questions you have..."
                    required
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-cyan-500 to-yellow-500 text-black hover:from-cyan-400 hover:to-yellow-400 transition-all duration-300 hover:scale-105"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </Button>
              </form>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-500/10 to-cyan-500/10 border border-green-500/20 rounded-full">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
            <span className="text-gray-300 text-sm">Available for collaborations and opportunities</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}