import { useState, useEffect } from 'react';
import { motion } from 'motion/react';

interface DateTimeProps {
  isDarkMode?: boolean;
}

export function DateTime({ isDarkMode = true }: DateTimeProps) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="fixed top-4 right-4 z-50 font-mono select-none"
    >
      <div className={`
        px-3 py-2 rounded-lg transition-all duration-300
        ${isDarkMode 
          ? 'bg-gray-900/40 backdrop-blur-sm text-gray-300' 
          : 'bg-white/60 backdrop-blur-sm text-gray-700 shadow-sm'
        }
      `}>
        {/* Time Display */}
        <motion.div
          key={formatTime(currentTime)}
          initial={{ opacity: 0.8 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
          className="text-sm font-medium tracking-wide"
        >
          {formatTime(currentTime)}
        </motion.div>
        
        {/* Date Display */}
        <div className={`
          text-xs mt-0.5 tracking-wide
          ${isDarkMode 
            ? 'text-gray-400' 
            : 'text-gray-500'
          }
        `}>
          {formatDate(currentTime)}
        </div>
      </div>
    </motion.div>
  );
}