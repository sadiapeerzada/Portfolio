import { motion } from 'motion/react';
import { useState } from 'react';

const skills = [
  { name: 'C', level: 90, icon: '⚡', color: 'from-blue-400 to-blue-600' },
  { name: 'Java', level: 85, icon: '☕', color: 'from-orange-400 to-red-500' },
  { name: 'HTML', level: 95, icon: '🌐', color: 'from-orange-500 to-red-600' },
  { name: 'CSS', level: 90, icon: '🎨', color: 'from-blue-500 to-purple-600' },
  { name: 'JavaScript', level: 80, icon: '⚡', color: 'from-yellow-400 to-yellow-600' },
  { name: 'DBMS', level: 85, icon: '🗃️', color: 'from-green-400 to-green-600' },
  { name: 'SQL', level: 80, icon: '📊', color: 'from-cyan-400 to-blue-500' },
];

const tools = [
  { name: 'VS Code', icon: '💻', color: 'text-blue-400' },
  { name: 'IntelliJ IDEA', icon: '🧠', color: 'text-orange-400' },
  { name: 'Dev-C++', icon: '⚙️', color: 'text-purple-400' },
  { name: 'macOS', icon: '🍎', color: 'text-gray-300' },
  { name: 'Windows', icon: '🪟', color: 'text-cyan-400' },
];

const otherSkills = [
  { name: 'API Integration', icon: '🔗', color: 'text-green-400' },
  { name: 'Web Deployment', icon: '🚀', color: 'text-yellow-400' },
  { name: 'Agile Development', icon: '🔄', color: 'text-purple-400' },
  { name: 'Problem Solving', icon: '🧩', color: 'text-cyan-400' },
  { name: 'Project Management', icon: '📋', color: 'text-pink-400' },
];

export function SkillsSection() {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  return (
    <section className="py-20 px-4" id="skills">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-8 bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent">
            Skills & Expertise
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-green-400 to-cyan-400 mx-auto rounded-full"></div>
        </motion.div>

        {/* Programming Languages */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl mb-8 text-center text-white">Programming Languages & Technologies</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 hover:border-cyan-400/50 transition-all duration-300"
                onMouseEnter={() => setHoveredSkill(skill.name)}
                onMouseLeave={() => setHoveredSkill(null)}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{skill.icon}</span>
                    <span className="text-white">{skill.name}</span>
                  </div>
                  <span className="text-cyan-400">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    transition={{ duration: 1.5, delay: index * 0.1 + 0.5 }}
                    viewport={{ once: true }}
                    className={`h-full bg-gradient-to-r ${skill.color} rounded-full relative`}
                  >
                    {hoveredSkill === skill.name && (
                      <div className="absolute inset-0 bg-white/20 rounded-full animate-pulse"></div>
                    )}
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Tools & Platforms */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl mb-8 text-center text-white">Tools & Platforms</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {tools.map((tool, index) => (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 text-center hover:border-cyan-400/50 transition-all duration-300 hover:scale-105"
              >
                <div className="text-3xl mb-2">{tool.icon}</div>
                <div className={`text-sm ${tool.color}`}>{tool.name}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Other Skills */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl mb-8 text-center text-white">Additional Expertise</h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {otherSkills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-xl p-6 text-center hover:border-cyan-400/50 transition-all duration-300 hover:scale-105"
              >
                <div className="text-3xl mb-2">{skill.icon}</div>
                <div className={`text-sm ${skill.color}`}>{skill.name}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}