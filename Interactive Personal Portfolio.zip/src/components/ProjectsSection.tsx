import { motion } from 'motion/react';
import { ExternalLink, Github } from 'lucide-react';
import weatherAppImage from 'figma:asset/188db1b2ec7c4e080d0054344bcf567bdfec893f.png';
import amuStudySphereImage from 'figma:asset/bae637ef657584c3c0b029135dda87e8a87303e3.png';
import todoListImage from 'figma:asset/707f30653221373d7377bc3ac04f67f870bcf3e8.png';
import passwordGeneratorImage from 'figma:asset/10933a36bb448660428f321601c1236417e3c4c2.png';
import quoteGeneratorImage from 'figma:asset/6a6a8fec5ad9feb550de99b7a4f116544447ee80.png';
import iosCalculatorImage from 'figma:asset/58605c4697f421154f771bc08a19979e21bee067.png';
import qrCodeGeneratorImage from 'figma:asset/6c493ae62b7814fbf5513cd1350520b8ea5c58f8.png';
import ageCalculatorImage from 'figma:asset/1771228291a07af118cdf7b8e9be617a7bdfc8f1.png';
import nasaSpaceExplorerImage from 'figma:asset/7af007ad22ff331de3856ae70d92a44bc3f31097.png';

// SVG Technology Icons
const TechIcons = {
  HTML: () => (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path fill="#E34F26" d="M1.5 0h21l-1.91 21.563L11.977 24l-8.564-2.438L1.5 0zm7.031 9.75l-.232-2.718 10.059.003.23-2.622L5.412 4.41l.698 8.01h9.126l-.326 3.426-2.91.804-2.955-.81-.188-2.11H6.248l.33 4.171L12 19.351l5.379-1.443.744-8.157H8.531z"/>
    </svg>
  ),
  CSS: () => (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path fill="#1572B6" d="M1.5 0h21l-1.91 21.563L11.977 24l-8.565-2.438L1.5 0zm17.09 4.413L5.41 4.41l.213 2.622 10.125.002-.255 2.716h-6.64l.24 2.573h6.182l-.366 3.523-2.91.804-2.956-.81-.188-2.11h-2.61l.29 3.855L12 19.288l5.373-1.53L18.59 4.414z"/>
    </svg>
  ),
  JavaScript: () => (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path fill="#F7DF1E" d="M0 0h24v24H0V0zm22.034 18.276c-.175-1.095-.888-2.015-3.003-2.873-.736-.345-1.554-.585-1.797-1.14-.091-.33-.105-.51-.046-.705.15-.646.915-.84 1.515-.66.39.12.75.42.976.9 1.034-.676 1.034-.676 1.755-1.125-.27-.42-.404-.601-.586-.78-.63-.705-1.469-1.065-2.834-1.034l-.705.089c-.676.165-1.32.525-1.71 1.005-1.14 1.291-.811 3.541.569 4.471 1.365 1.02 3.361 1.244 3.616 2.205.24 1.17-.87 1.545-1.966 1.41-.811-.18-1.26-.586-1.755-1.336l-1.83 1.051c.21.48.45.689.81 1.109 1.74 1.756 6.09 1.666 6.871-1.004.029-.09.24-.705.074-1.65l.046.067zm-8.983-7.245h-2.248c0 1.938-.009 3.864-.009 5.805 0 1.232.063 2.363-.138 2.711-.33.689-1.18.601-1.566.48-.396-.196-.597-.466-.83-.855-.063-.105-.11-.196-.127-.196l-1.825 1.125c.305.63.75 1.172 1.324 1.517.855.51 2.004.675 3.207.405.783-.226 1.458-.691 1.811-1.411.51-.93.402-2.07.397-3.346.012-2.054 0-4.109 0-6.179l.004-.056z"/>
    </svg>
  ),
  APIs: () => (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path fill="#61DAFB" d="M12 15.5c1.93 0 3.5-1.57 3.5-3.5s-1.57-3.5-3.5-3.5-3.5 1.57-3.5 3.5 1.57 3.5 3.5 3.5z"/>
      <path fill="#61DAFB" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15-1-4-1 4-4-1 4-1-4-1 4-1 1-4 1 4 4 1-4 1 4 1-4 1z"/>
    </svg>
  ),
  DBMS: () => (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path fill="#336791" d="M12 0C5.373 0 0 2.686 0 6v12c0 3.314 5.373 6 12 6s12-2.686 12-6V6c0-3.314-5.373-6-12-6zm0 2c5.523 0 10 2.015 10 4.5S17.523 11 12 11 2 8.985 2 6.5 6.477 2 12 2zm0 18c-5.523 0-10-2.015-10-4.5v-2.25c2.1 1.398 5.775 2.25 10 2.25s7.9-.852 10-2.25V15.5c0 2.485-4.477 4.5-10 4.5z"/>
    </svg>
  )
};

const projects = [
  {
    id: 1,
    title: "Weather App",
    description: "A beautiful weather forecasting app that fetches real-time weather updates for any city with stunning UI and detailed weather metrics.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript },
      { name: "OpenWeather API", icon: TechIcons.APIs }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/Weather-App",
    status: "Live",
    category: "Web App",
    image: weatherAppImage,
    color: "from-cyan-500 to-blue-500"
  },
  {
    id: 2,
    title: "AMU StudySphere",
    description: "A comprehensive student productivity and resource portal for AMU students with AI-powered tools, study groups, notes, and course resources.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript },
      { name: "DBMS", icon: TechIcons.DBMS },
      { name: "APIs", icon: TechIcons.APIs }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/AMU-StudySphere",
    status: "Live",
    category: "EdTech",
    image: amuStudySphereImage,
    color: "from-green-500 to-emerald-600"
  },
  {
    id: 3,
    title: "TodoList Pro",
    description: "A sleek and intuitive task management application with clean design, drag-and-drop functionality, and productivity features.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/TodoList-Pro",
    status: "Live",
    category: "Productivity",
    image: todoListImage,
    color: "from-purple-500 to-pink-600"
  },
  {
    id: 4,
    title: "Random Password Generator",
    description: "A secure password generator with customizable settings, copy functionality, and strong encryption algorithms for enhanced cybersecurity.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/Random-Password-Generator",
    status: "Live",
    category: "Security",
    image: passwordGeneratorImage,
    color: "from-emerald-500 to-teal-600"
  },
  {
    id: 5,
    title: "Quote Generator",
    description: "An inspiring daily quote generator with social sharing features, beautiful typography, and motivational content from famous personalities.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript },
      { name: "APIs", icon: TechIcons.APIs }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/Quote-Generator",
    status: "Live",
    category: "Lifestyle",
    image: quoteGeneratorImage,
    color: "from-indigo-500 to-purple-600"
  },
  {
    id: 6,
    title: "iOS Calculator",
    description: "A pixel-perfect iOS calculator clone with smooth animations, gesture support, and advanced mathematical operations in a native-like interface.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/iOS-Calculator",
    status: "Live",
    category: "Mobile UI",
    image: iosCalculatorImage,
    color: "from-gray-500 to-slate-600"
  },
  {
    id: 7,
    title: "QR Code Generator",
    description: "A versatile QR code generator that converts text, URLs, and data into scannable QR codes with customizable design options and instant download functionality.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/QR-Code-Generator",
    status: "Live",
    category: "Utility",
    image: qrCodeGeneratorImage,
    color: "from-blue-500 to-indigo-600"
  },
  {
    id: 8,
    title: "Age Calculator",
    description: "A precise age calculator with beautiful purple gradient design that computes exact age in years, months, and days with date validation and user-friendly interface.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/Age-Calculator",
    status: "Live",
    category: "Calculator",
    image: ageCalculatorImage,
    color: "from-purple-500 to-violet-600"
  },
  {
    id: 9,
    title: "NASA Space Explorer",
    description: "A comprehensive space exploration app featuring real-time NASA APIs, Astronomy Picture of the Day, Mars Rover photos, ISS tracking, space facts, and interactive quizzes.",
    technologies: [
      { name: "HTML", icon: TechIcons.HTML },
      { name: "CSS", icon: TechIcons.CSS },
      { name: "JavaScript", icon: TechIcons.JavaScript },
      { name: "NASA APIs", icon: TechIcons.APIs }
    ],
    demoUrl: "#",
    githubUrl: "https://github.com/sadiapeerzada/NASA-Space-Explorer",
    status: "Live",
    category: "API Integration",
    image: nasaSpaceExplorerImage,
    color: "from-orange-500 to-red-600"
  }
];

export function ProjectsSection() {
  return (
    <section className="py-20 px-4" id="projects">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-8 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent leading-tight py-2">
            Projects
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-400 to-pink-400 mx-auto rounded-full"></div>
          <p className="text-gray-300 mt-6 max-w-2xl mx-auto">
            A comprehensive portfolio of 9 innovative web applications demonstrating expertise in frontend development, API integration, utility tools, space technology, and modern UI/UX design.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl overflow-hidden hover:border-cyan-400/50 transition-all duration-500 hover:scale-105">
                {/* Project Header */}
                <div className={`h-48 bg-gradient-to-br ${project.color} relative overflow-hidden`}>
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="absolute inset-0 w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 bg-black/40"></div>
                  <div className="absolute top-4 right-4">
                    <span className={`px-3 py-1 rounded-full text-xs ${
                      project.status === 'Live' 
                        ? 'bg-green-500/20 text-green-400 border border-green-500/30 backdrop-blur-sm' 
                        : 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 backdrop-blur-sm'
                    }`}>
                      {project.status}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <span className="px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full text-xs text-white border border-white/20">
                      {project.category}
                    </span>
                  </div>
                </div>

                {/* Project Content */}
                <div className="p-6">
                  <h3 className="text-xl mb-3 text-white group-hover:text-cyan-400 transition-colors duration-300">
                    {project.title}
                  </h3>
                  
                  <p className="text-gray-300 text-sm mb-4 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Technologies */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.technologies.map((tech, techIndex) => (
                      <div
                        key={techIndex}
                        className="flex items-center gap-2 px-3 py-1 bg-gray-800/50 text-cyan-400 rounded-full text-xs border border-cyan-400/30"
                      >
                        <tech.icon />
                        <span>{tech.name}</span>
                      </div>
                    ))}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-4">
                    <a
                      href={project.demoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg hover:shadow-lg hover:shadow-cyan-400/25 transition-all duration-300 text-sm"
                    >
                      <ExternalLink size={16} />
                      Demo
                    </a>
                    <a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gray-800 text-gray-300 rounded-lg hover:bg-gray-700 hover:text-white transition-all duration-300 text-sm border border-gray-600"
                    >
                      <Github size={16} />
                      Code
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20 rounded-2xl p-8">
            <h3 className="text-2xl mb-4 text-white">Want to see more?</h3>
            <p className="text-gray-300 mb-6">
              These are just a few highlights. Check out my GitHub for more projects and contributions.
            </p>
            <motion.a
              href="https://github.com/sadiapeerzada"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:shadow-lg hover:shadow-purple-400/25 transition-all duration-300"
              whileHover={{ 
                scale: 1.05,
                boxShadow: "0 10px 30px rgba(168, 85, 247, 0.3)"
              }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              >
                <Github size={20} />
              </motion.div>
              View All Projects
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}