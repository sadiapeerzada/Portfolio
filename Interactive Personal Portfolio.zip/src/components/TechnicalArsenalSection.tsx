import { motion } from 'motion/react';
import { useState, useEffect } from 'react';
import intellijLogo from 'figma:asset/a65cc9a3396240ce75dc227c8952e3122d53ac9f.png';

// SVG Logo Components
const CLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#00599C" d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.568 16.568c-.292.292-.767.292-1.06 0L12 12.06l-4.508 4.508c-.292.292-.767.292-1.06 0s-.292-.767 0-1.06L10.94 12 6.432 7.492c-.292-.292-.292-.767 0-1.06s.767-.292 1.06 0L12 10.94l4.508-4.508c.292-.292.767-.292 1.06 0s.292.767 0 1.06L13.06 12l4.508 4.508c.292.292.292.767 0 1.06z"/>
    <text x="12" y="16" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">C</text>
  </svg>
);

const JavaLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#ED8B00" d="M8.851 18.56s-.917.534.653.714c1.902.218 2.874.187 4.969-.211 0 0 .552.346 1.321.646-4.699 2.013-10.633-.118-6.943-1.149M8.276 15.933s-1.028.761.542.924c2.032.209 3.636.227 6.413-.308 0 0 .384.389.987.602-5.679 1.661-12.007.13-7.942-1.218M13.116 11.475c1.158 1.333-.304 2.533-.304 2.533s2.939-1.518 1.589-3.418c-1.261-1.772-2.228-2.652 3.007-5.688 0-.001-8.216 2.051-4.292 6.573M19.33 20.504s.679.559-.747.991c-2.712.822-11.288 1.069-13.669.033-.856-.373.75-.89 1.254-.998.527-.114.828-.093.828-.093-.953-.671-6.156 1.317-2.643 1.887 9.58 1.553 17.462-.7 14.977-1.82M9.292 13.21s-4.362 1.036-1.544 1.412c1.189.159 3.561.123 5.77-.062 1.806-.152 3.618-.477 3.618-.477s-.637.272-1.098.587c-4.429 1.165-12.986.623-10.522-.568 2.082-1.006 3.776-.892 3.776-.892M17.116 17.584c4.503-2.34 2.421-4.589.968-4.285-.355.074-.515.138-.515.138s.132-.207.385-.297c2.875-1.011 5.086 2.981-.928 4.562 0-.001.07-.062.09-.118M14.401 0s2.494 2.494-2.365 6.33c-3.896 3.077-.888 4.832-.001 6.836-2.274-2.053-3.943-3.858-2.824-5.539 1.644-2.469 6.197-3.665 5.19-7.627M9.734 23.924c4.322.277 10.959-.153 11.116-2.198 0 0-.302.775-3.572 1.391-3.688.694-8.239.613-10.937.168 0-.001.553.457 3.393.639"/>
  </svg>
);

const HTML5Logo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#E34F26" d="M1.5 0h21l-1.91 21.563L11.977 24l-8.564-2.438L1.5 0zm7.031 9.75l-.232-2.718 10.059.003.23-2.622L5.412 4.41l.698 8.01h9.126l-.326 3.426-2.91.804-2.955-.81-.188-2.11H6.248l.33 4.171L12 19.351l5.379-1.443.744-8.157H8.531z"/>
  </svg>
);

const CSS3Logo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#1572B6" d="M1.5 0h21l-1.91 21.563L11.977 24l-8.565-2.438L1.5 0zm17.09 4.413L5.41 4.41l.213 2.622 10.125.002-.255 2.716h-6.64l.24 2.573h6.182l-.366 3.523-2.91.804-2.956-.81-.188-2.11h-2.61l.29 3.855L12 19.288l5.373-1.53L18.59 4.414z"/>
  </svg>
);

const JavaScriptLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#F7DF1E" d="M0 0h24v24H0V0zm22.034 18.276c-.175-1.095-.888-2.015-3.003-2.873-.736-.345-1.554-.585-1.797-1.14-.091-.33-.105-.51-.046-.705.15-.646.915-.84 1.515-.66.39.12.75.42.976.9 1.034-.676 1.034-.676 1.755-1.125-.27-.42-.404-.601-.586-.78-.63-.705-1.469-1.065-2.834-1.034l-.705.089c-.676.165-1.32.525-1.71 1.005-1.14 1.291-.811 3.541.569 4.471 1.365 1.02 3.361 1.244 3.616 2.205.24 1.17-.87 1.545-1.966 1.41-.811-.18-1.26-.586-1.755-1.336l-1.83 1.051c.21.48.45.689.81 1.109 1.74 1.756 6.09 1.666 6.871-1.004.029-.09.24-.705.074-1.65l.046.067zm-8.983-7.245h-2.248c0 1.938-.009 3.864-.009 5.805 0 1.232.063 2.363-.138 2.711-.33.689-1.18.601-1.566.48-.396-.196-.597-.466-.83-.855-.063-.105-.11-.196-.127-.196l-1.825 1.125c.305.63.75 1.172 1.324 1.517.855.51 2.004.675 3.207.405.783-.226 1.458-.691 1.811-1.411.51-.93.402-2.07.397-3.346.012-2.054 0-4.109 0-6.179l.004-.056z"/>
  </svg>
);

const SQLLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#336791" d="M12 0C5.373 0 0 2.686 0 6v12c0 3.314 5.373 6 12 6s12-2.686 12-6V6c0-3.314-5.373-6-12-6zm0 2c5.523 0 10 2.015 10 4.5S17.523 11 12 11 2 8.985 2 6.5 6.477 2 12 2zm0 18c-5.523 0-10-2.015-10-4.5v-2.25c2.1 1.398 5.775 2.25 10 2.25s7.9-.852 10-2.25V15.5c0 2.485-4.477 4.5-10 4.5z"/>
    <text x="12" y="9" textAnchor="middle" fill="white" fontSize="4" fontWeight="bold">SQL</text>
  </svg>
);

const DBMSLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#FF6B35" d="M12 0C5.373 0 0 2.686 0 6v3c0 3.314 5.373 6 12 6s12-2.686 12-6V6c0-3.314-5.373-6-12-6zm0 2c5.523 0 10 2.015 10 4.5S17.523 11 12 11 2 8.985 2 6.5 6.477 2 12 2zm0 11c-5.523 0-10-2.015-10-4.5v2.25c2.1 1.398 5.775 2.25 10 2.25s7.9-.852 10-2.25V8.5c0 2.485-4.477 4.5-10 4.5zm0 7c-5.523 0-10-2.015-10-4.5v2.25c2.1 1.398 5.775 2.25 10 2.25s7.9-.852 10-2.25V15.5c0 2.485-4.477 4.5-10 4.5z"/>
  </svg>
);

const MacOSLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#FFFFFF" d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
  </svg>
);

const WindowsLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#00A1F1" d="M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-13.051-1.342"/>
  </svg>
);

const VSCodeLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8" style={{ width: '32px', height: '32px' }}>
    <path fill="#007ACC" d="M23.15 2.587L18.21.21a1.494 1.494 0 0 0-1.705.29l-9.46 8.63-4.12-3.128a.999.999 0 0 0-1.276.057L.327 7.261A1 1 0 0 0 .326 8.74L3.899 12 .326 15.26a1 1 0 0 0 .001 1.479L1.65 17.94a.999.999 0 0 0 1.276.057l4.12-3.128 9.46 8.63a1.492 1.492 0 0 0 1.704.29l4.942-2.377A1.5 1.5 0 0 0 24 20.06V3.939a1.5 1.5 0 0 0-.85-1.352zm-5.146 14.861L10.826 12l7.178-5.448v10.896z"/>
  </svg>
);

const IntelliJLogo = () => (
  <img 
    src={intellijLogo} 
    alt="IntelliJ IDEA" 
    className="w-8 h-8 object-cover"
    style={{ width: '32px', height: '32px' }}
  />
);

const DevCppLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#00599C" d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0z"/>
    <text x="12" y="16" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold">C++</text>
  </svg>
);

const GitLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#F05032" d="M23.546 10.93L13.067.452c-.604-.603-1.582-.603-2.188 0L8.708 2.627l2.76 2.76c.645-.215 1.379-.07 1.889.441.516.515.658 1.258.438 1.9l2.658 2.66c.645-.223 1.387-.078 1.9.435.721.72.721 1.884 0 2.604-.719.719-1.881.719-2.6 0-.539-.541-.674-1.337-.404-1.996L12.86 8.955v6.525c.176.086.342.203.488.348.713.721.713 1.883 0 2.6-.719.721-1.889.721-2.609 0-.719-.719-.719-1.879 0-2.598.182-.18.387-.316.605-.406V8.835c-.217-.091-.424-.222-.6-.401-.545-.545-.676-1.342-.396-2.009L7.636 3.7.45 10.881c-.6.605-.6 1.584 0 2.189l10.48 10.477c.604.604 1.582.604 2.186 0l10.43-10.43c.605-.603.605-1.582 0-2.187"/>
  </svg>
);

const GitHubLogo = () => (
  <svg viewBox="0 0 24 24" className="w-8 h-8">
    <path fill="#181717" d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
  </svg>
);

const programmingLanguages = [
  { name: 'DBMS', level: 85, color: 'from-green-400 to-green-600', logo: DBMSLogo },
  { name: 'SQL', level: 80, color: 'from-cyan-400 to-blue-500', logo: SQLLogo },
  { name: 'JavaScript', level: 80, color: 'from-yellow-400 to-yellow-600', logo: JavaScriptLogo },
  { name: 'CSS3', level: 90, color: 'from-blue-500 to-purple-600', logo: CSS3Logo },
  { name: 'HTML5', level: 95, color: 'from-orange-500 to-red-600', logo: HTML5Logo },
  { name: 'Java', level: 85, color: 'from-orange-400 to-red-500', logo: JavaLogo },
  { name: 'C', level: 90, color: 'from-blue-400 to-blue-600', logo: CLogo },
  { name: 'Git', level: 88, color: 'from-red-400 to-orange-500', logo: GitLogo },
  { name: 'GitHub', level: 92, color: 'from-gray-600 to-gray-800', logo: GitHubLogo },
];

const operatingSystems = [
  { name: 'Windows', color: 'text-cyan-400', logo: WindowsLogo },
  { name: 'macOS', color: 'text-gray-300', logo: MacOSLogo },
];

const developmentTools = [
  { name: 'Dev-C++', color: 'text-purple-400', logo: DevCppLogo },
  { name: 'IntelliJ IDEA', color: 'text-orange-400', logo: IntelliJLogo },
  { name: 'VS Code', color: 'text-blue-400', logo: VSCodeLogo },
];

const specializations = [
  { 
    name: 'API Integration', 
    color: 'text-green-400', 
    bgColor: 'from-green-400/10 to-emerald-400/10', 
    borderColor: 'border-green-400/30',
    description: 'Seamless third-party integrations',
    icon: '🔗',
    level: '90%'
  },
  { 
    name: 'Web App Deployment', 
    color: 'text-yellow-400', 
    bgColor: 'from-yellow-400/10 to-orange-400/10', 
    borderColor: 'border-yellow-400/30',
    description: 'Cloud & server deployment',
    icon: '🚀',
    level: '85%'
  },
  { 
    name: 'Agile Development', 
    color: 'text-purple-400', 
    bgColor: 'from-purple-400/10 to-pink-400/10', 
    borderColor: 'border-purple-400/30',
    description: 'Scrum & iterative methodology',
    icon: '⚡',
    level: '88%'
  },
  { 
    name: 'Problem Solving', 
    color: 'text-cyan-400', 
    bgColor: 'from-cyan-400/10 to-blue-400/10', 
    borderColor: 'border-cyan-400/30',
    description: 'Analytical & critical thinking',
    icon: '🧠',
    level: '95%'
  },
  { 
    name: 'Project Management', 
    color: 'text-pink-400', 
    bgColor: 'from-pink-400/10 to-red-400/10', 
    borderColor: 'border-pink-400/30',
    description: 'Team coordination & delivery',
    icon: '📋',
    level: '82%'
  },
  { 
    name: 'Event Management', 
    color: 'text-indigo-400', 
    bgColor: 'from-indigo-400/10 to-violet-400/10', 
    borderColor: 'border-indigo-400/30',
    description: 'Planning & executing events',
    icon: '🎪',
    level: '86%'
  },
];

const coreSkills = [
  { 
    name: 'Full-Stack Development', 
    color: 'text-blue-400', 
    bgColor: 'from-blue-400/10 to-cyan-400/10', 
    borderColor: 'border-blue-400/30',
    description: 'End-to-end web applications',
    icon: '💻',
    level: '92%'
  },
  { 
    name: 'Problem Solving', 
    color: 'text-cyan-400', 
    bgColor: 'from-cyan-400/10 to-blue-400/10', 
    borderColor: 'border-cyan-400/30',
    description: 'Analytical & critical thinking',
    icon: '🎯',
    level: '95%'
  },
  { 
    name: 'AI Integration', 
    color: 'text-purple-400', 
    bgColor: 'from-purple-400/10 to-indigo-400/10', 
    borderColor: 'border-purple-400/30',
    description: 'Machine learning & AI APIs',
    icon: '🤖',
    level: '78%'
  },
  { 
    name: 'Startup Development', 
    color: 'text-yellow-400', 
    bgColor: 'from-yellow-400/10 to-orange-400/10', 
    borderColor: 'border-yellow-400/30',
    description: 'MVP & rapid prototyping',
    icon: '💡',
    level: '87%'
  },
  { 
    name: 'IoT Solutions', 
    color: 'text-green-400', 
    bgColor: 'from-green-400/10 to-emerald-400/10', 
    borderColor: 'border-green-400/30',
    description: 'Connected device ecosystems',
    icon: '🌐',
    level: '75%'
  },
  { 
    name: 'Deep Learning', 
    color: 'text-pink-400', 
    bgColor: 'from-pink-400/10 to-purple-400/10', 
    borderColor: 'border-pink-400/30',
    description: 'Neural networks & ML models',
    icon: '🧠',
    level: '83%'
  },
];



export function TechnicalArsenalSection({ isDarkMode = true }: { isDarkMode?: boolean }) {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  return (
    <section className={`py-20 px-4 ${
      isDarkMode ? '' : 'bg-gray-50'
    }`} id="skills">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className={`text-4xl md:text-5xl mb-8 ${
            isDarkMode 
              ? 'bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent'
              : 'text-gray-800'
          }`}>
            Technical Arsenal
          </h2>
          <div className={`w-24 h-1 mx-auto rounded-full ${
            isDarkMode 
              ? 'bg-gradient-to-r from-green-400 to-cyan-400'
              : 'bg-gray-300'
          }`}></div>
          <p className={`mt-6 max-w-2xl mx-auto ${
            isDarkMode ? 'text-gray-300' : 'text-gray-600'
          }`}>
            A comprehensive overview of my technical skills, tools, and expertise across various domains of software development.
          </p>
        </motion.div>

        {/* Programming Languages */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className={`text-2xl mb-8 text-center ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>Programming Languages & Technologies</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {programmingLanguages.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`rounded-xl p-6 transition-all duration-300 hover:scale-105 ${
                  isDarkMode 
                    ? 'bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 hover:border-cyan-400/50'
                    : 'bg-white border border-gray-200 hover:border-gray-300 shadow-sm hover:shadow-lg'
                }`}
                onMouseEnter={() => setHoveredSkill(skill.name)}
                onMouseLeave={() => setHoveredSkill(null)}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 flex items-center justify-center">
                      <skill.logo />
                    </div>
                    <span className={isDarkMode ? 'text-white' : 'text-gray-800'}>{skill.name}</span>
                  </div>
                  <span className={`${
                    isDarkMode ? 'text-cyan-400' : 'text-gray-600'
                  }`}>{skill.level}%</span>
                </div>
                <div className={`w-full rounded-full h-2 overflow-hidden ${
                  isDarkMode ? 'bg-gray-700' : 'bg-gray-200'
                }`}>
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.level}%` }}
                    transition={{ duration: 1.5, delay: index * 0.1 + 0.5 }}
                    viewport={{ once: true }}
                    className={`h-full rounded-full relative ${
                      isDarkMode 
                        ? `bg-gradient-to-r ${skill.color}`
                        : 'bg-gray-600'
                    }`}
                  >
                    {hoveredSkill === skill.name && (
                      <div className={`absolute inset-0 rounded-full animate-pulse ${
                        isDarkMode ? 'bg-white/20' : 'bg-white/40'
                      }`}></div>
                    )}
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Operating Systems */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className={`text-2xl mb-8 text-center ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>Operating Systems</h3>
          <div className="grid grid-cols-2 md:grid-cols-2 gap-6 max-w-md mx-auto">
            {operatingSystems.map((os, index) => (
              <motion.div
                key={os.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`rounded-xl p-6 text-center transition-all duration-300 hover:scale-105 ${
                  isDarkMode 
                    ? 'bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 hover:border-cyan-400/50'
                    : 'bg-white border border-gray-200 hover:border-gray-300 shadow-sm hover:shadow-lg'
                }`}
              >
                <div className="w-12 h-12 flex items-center justify-center mb-2 mx-auto">
                  <os.logo />
                </div>
                <div className={`${isDarkMode ? os.color : 'text-gray-700'}`}>{os.name}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Development Tools */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className={`text-2xl mb-8 text-center ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>Development Tools</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {developmentTools.map((tool, index) => (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`rounded-xl p-6 text-center transition-all duration-300 hover:scale-105 ${
                  isDarkMode 
                    ? 'bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 hover:border-cyan-400/50'
                    : 'bg-white border border-gray-200 hover:border-gray-300 shadow-sm hover:shadow-lg'
                }`}
              >
                <div className="w-12 h-12 flex items-center justify-center mb-2 mx-auto">
                  <tool.logo />
                </div>
                <div className={`${isDarkMode ? tool.color : 'text-gray-700'}`}>{tool.name}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Specializations */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className={`text-2xl mb-8 text-center ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>Specializations</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {specializations.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`rounded-xl p-6 text-center transition-all duration-300 hover:scale-105 ${
                  isDarkMode 
                    ? `bg-gradient-to-br ${skill.bgColor} backdrop-blur-sm border ${skill.borderColor} hover:shadow-lg`
                    : 'bg-white border border-gray-200 hover:border-gray-300 shadow-sm hover:shadow-lg'
                }`}
              >
                <div className="text-3xl mb-3">{skill.icon}</div>
                <h4 className={`text-lg mb-2 ${isDarkMode ? skill.color : 'text-gray-800'}`}>
                  {skill.name}
                </h4>
                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {skill.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Core Skills */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className={`text-2xl mb-8 text-center ${
            isDarkMode ? 'text-white' : 'text-gray-800'
          }`}>Core Skills</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {coreSkills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`rounded-xl p-6 text-center transition-all duration-300 hover:scale-105 ${
                  isDarkMode 
                    ? `bg-gradient-to-br ${skill.bgColor} backdrop-blur-sm border ${skill.borderColor} hover:shadow-lg`
                    : 'bg-white border border-gray-200 hover:border-gray-300 shadow-sm hover:shadow-lg'
                }`}
              >
                <div className="text-3xl mb-3">{skill.icon}</div>
                <h4 className={`text-lg mb-2 ${isDarkMode ? skill.color : 'text-gray-800'}`}>
                  {skill.name}
                </h4>
                <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {skill.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}