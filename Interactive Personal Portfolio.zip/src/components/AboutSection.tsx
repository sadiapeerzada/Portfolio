import { motion } from 'motion/react';
import profileImage from 'figma:asset/8945bd12f991fd533bdb10dd5c02961634408565.png';
import groupImage from 'figma:asset/e697712909d0fbec30bce559a7ce1391b0b53149.png';
import newProfileImage from 'figma:asset/742be90fab3c3f4d4d0f52e305fcc402e77f2c32.png';

export function AboutSection() {
  return (
    <section className="py-20 px-4" id="about">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-8 bg-gradient-to-r from-cyan-400 to-yellow-400 bg-clip-text text-transparent">
            About Me
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-cyan-400 to-yellow-400 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image Section */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative">
              {/* Decorative Background */}
              <motion.div 
                className="absolute -inset-4 bg-gradient-to-r from-cyan-400/20 via-blue-400/20 to-purple-400/20 rounded-3xl blur-2xl"
                animate={{ 
                  scale: [1, 1.05, 1],
                  rotate: [0, 2, 0]
                }}
                transition={{ 
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              ></motion.div>
              
              {/* Main Image Container */}
              <div className="relative bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-xl rounded-3xl p-2 border border-gray-600/30">
                <motion.img
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                  viewport={{ once: true }}
                  src={newProfileImage}
                  alt="Sadia Peerzada - Professional Portrait"
                  className="w-full h-[500px] object-cover rounded-3xl shadow-2xl"
                />
                
                {/* Floating Animation Dots */}
                <motion.div 
                  className="absolute top-4 right-4 w-4 h-4 bg-cyan-400 rounded-full opacity-60"
                  animate={{
                    y: [0, -10, 0],
                    opacity: [0.6, 1, 0.6]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                ></motion.div>
                <motion.div 
                  className="absolute bottom-4 left-4 w-3 h-3 bg-purple-400 rounded-full opacity-60"
                  animate={{
                    y: [0, -8, 0],
                    opacity: [0.6, 1, 0.6]
                  }}
                  transition={{
                    duration: 2.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5
                  }}
                ></motion.div>
              </div>
            </div>
          </motion.div>

          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
            className="bg-gray-900/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 md:p-12 shadow-2xl"
            style={{ fontFamily: 'Poppins, sans-serif' }}
          >
            <div className="prose prose-lg prose-invert max-w-none">
              <p className="text-gray-200 leading-relaxed text-lg mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Hi, I'm Sadia Peerzada, a <span className="text-cyan-400 px-1">BCA second-year student, developer, and coder</span>, 
                passionate about exploring technology, building software solutions, and creating innovative projects.
              </p>
              
              <p className="text-gray-200 leading-relaxed text-lg mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                I'm deeply interested in programming, application development, and integrating APIs to make intelligent and 
                interactive software. As a student and developer, I have hands-on experience with programming languages like 
                <span className="text-yellow-400 px-1">C, Java, HTML, CSS, JavaScript, SQL, and DBMS</span>.
              </p>

              <p className="text-gray-200 leading-relaxed text-lg mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                I'm comfortable working in both <span className="text-green-400 px-1">macOS and Windows</span> environments 
                using development tools like <span className="text-purple-400 px-1">VS Code, IntelliJ IDEA, and Dev-C++</span>. 
                I specialize in API integration and have experience with web app deployment, agile development, problem solving, 
                and project management.
              </p>

              <p className="text-gray-200 leading-relaxed text-lg mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
                I thrive on designing creative, functional, and user-friendly applications, constantly experimenting with new 
                technologies and applying my skills to solve real-world problems. I enjoy building projects that integrate 
                multiple components, whether it's web development, coding challenges, or AI-powered tools.
              </p>

              <p className="text-gray-200 leading-relaxed text-lg mb-8" style={{ fontFamily: 'Poppins, sans-serif' }}>
                My focus is to leverage my skills as a student, developer, and coder to build meaningful projects, innovate in 
                technology, and grow as a <span className="text-cyan-400 px-1">future tech entrepreneur</span>.
              </p>

              {/* Download Resume Button */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
                className="flex justify-center md:justify-start"
              >
                <motion.a
                  href="https://drive.google.com/uc?export=download&id=1cfyjQeHoiACG81OSMooTtU5rGlCoO9Ul"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ 
                    scale: 1.05,
                    boxShadow: "0 10px 30px rgba(34, 211, 238, 0.3)"
                  }}
                  whileTap={{ scale: 0.95 }}
                  className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-xl font-medium transition-all duration-300 shadow-lg hover:shadow-cyan-500/25"
                  style={{ fontFamily: 'Poppins, sans-serif' }}
                >
                  <svg 
                    className="w-5 h-5" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" 
                    />
                  </svg>
                  Download Resume
                </motion.a>
              </motion.div>
            </div>
          </motion.div>
        </div>



        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <motion.div 
            initial={{ opacity: 0, y: 30, rotateY: -15 }}
            whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            viewport={{ once: true }}
            whileHover={{ 
              scale: 1.05, 
              rotateY: 5,
              boxShadow: "0 10px 30px rgba(34, 211, 238, 0.2)"
            }}
            className="text-center p-6 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-xl border border-cyan-500/20 cursor-pointer"
          >
            <motion.div 
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
              className="text-3xl text-cyan-400 mb-2"
            >
              🎯
            </motion.div>
            <h3 className="text-cyan-400 mb-2">Problem Solver</h3>
            <p className="text-gray-300 text-sm">Passionate about finding innovative solutions to complex challenges</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            viewport={{ once: true }}
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 10px 30px rgba(251, 191, 36, 0.2)"
            }}
            className="text-center p-6 bg-gradient-to-br from-yellow-500/10 to-orange-500/10 rounded-xl border border-yellow-500/20 cursor-pointer"
          >
            <motion.div 
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 2 }}
              className="text-3xl text-yellow-400 mb-2"
            >
              🚀
            </motion.div>
            <h3 className="text-yellow-400 mb-2">Tech Enthusiast</h3>
            <p className="text-gray-300 text-sm">Always exploring cutting-edge technologies and frameworks</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 30, rotateY: 15 }}
            whileInView={{ opacity: 1, y: 0, rotateY: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
            viewport={{ once: true }}
            whileHover={{ 
              scale: 1.05, 
              rotateY: -5,
              boxShadow: "0 10px 30px rgba(34, 197, 94, 0.2)"
            }}
            className="text-center p-6 bg-gradient-to-br from-green-500/10 to-emerald-500/10 rounded-xl border border-green-500/20 cursor-pointer"
          >
            <motion.div 
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 4 }}
              className="text-3xl text-green-400 mb-2"
            >
              🌟
            </motion.div>
            <h3 className="text-green-400 mb-2">Collaborator</h3>
            <p className="text-gray-300 text-sm">Thrives in team environments and loves sharing knowledge</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}