import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

interface LoadingAnimationProps {
  onComplete: () => void;
}

export function LoadingAnimation({ onComplete }: LoadingAnimationProps) {
  const [pacmanPosition, setPacmanPosition] = useState(0);
  const [ghostPositions, setGhostPositions] = useState([0, -50, -100, -150]);
  const [dotsEaten, setDotsEaten] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setPacmanPosition(prev => {
        const newPos = prev + 5;
        if (newPos >= window.innerWidth + 100) {
          setTimeout(onComplete, 500);
          return newPos;
        }
        return newPos;
      });

      setGhostPositions(prev => 
        prev.map(pos => pos + 3)
      );

      if (pacmanPosition % 80 === 0) {
        setDotsEaten(prev => prev + 1);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [pacmanPosition, onComplete]);

  const dots = Array.from({ length: 15 }, (_, i) => i * 80 + 100);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 bg-black flex items-center justify-center overflow-hidden"
    >
      {/* Background grid */}
      <div className="absolute inset-0 opacity-20">
        <div className="grid-background"></div>
      </div>

      {/* Game area */}
      <div className="relative w-full h-32">
        {/* Glowing dots */}
        {dots.map((dotX, index) => (
          <motion.div
            key={index}
            className={`absolute w-3 h-3 rounded-full ${
              pacmanPosition > dotX ? 'opacity-0' : 'opacity-100'
            }`}
            style={{ 
              left: dotX, 
              top: '50%', 
              transform: 'translateY(-50%)',
              background: 'radial-gradient(circle, #00ffff 0%, #0080ff 100%)',
              boxShadow: '0 0 10px #00ffff, 0 0 20px #00ffff, 0 0 30px #00ffff'
            }}
            animate={{
              scale: [1, 1.2, 1],
              opacity: pacmanPosition > dotX ? [1, 0] : [0.8, 1, 0.8]
            }}
            transition={{
              duration: 0.5,
              repeat: pacmanPosition <= dotX ? Infinity : 0
            }}
          />
        ))}

        {/* Pac-Man */}
        <motion.div
          className="absolute w-8 h-8 rounded-full bg-yellow-400"
          style={{ 
            left: pacmanPosition, 
            top: '50%', 
            transform: 'translateY(-50%)',
            boxShadow: '0 0 15px #ffff00, 0 0 30px #ffff00'
          }}
          animate={{
            clipPath: [
              'polygon(0% 0%, 85% 50%, 0% 100%)',
              'polygon(0% 0%, 100% 50%, 0% 100%)',
              'polygon(0% 0%, 85% 50%, 0% 100%)'
            ]
          }}
          transition={{
            duration: 0.3,
            repeat: Infinity
          }}
        />

        {/* Ghosts */}
        {['#ff4444', '#ff44ff', '#44ff44', '#4444ff'].map((color, index) => (
          <motion.div
            key={index}
            className="absolute w-7 h-7 rounded-t-full"
            style={{ 
              left: ghostPositions[index], 
              top: '50%', 
              transform: 'translateY(-50%)',
              backgroundColor: color,
              boxShadow: `0 0 10px ${color}, 0 0 20px ${color}`,
              clipPath: 'polygon(0% 0%, 100% 0%, 100% 85%, 85% 100%, 70% 85%, 55% 100%, 40% 85%, 25% 100%, 10% 85%, 0% 100%)'
            }}
            animate={{
              y: [0, -3, 0]
            }}
            transition={{
              duration: 0.8,
              repeat: Infinity,
              delay: index * 0.2
            }}
          />
        ))}
      </div>

      {/* Loading text */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="absolute bottom-20 left-1/2 transform -translate-x-1/2 text-center"
      >
        <div className="text-cyan-400 text-2xl mb-4">Loading Portfolio...</div>
        <div className="flex items-center justify-center gap-2">
          <div className="w-12 h-1 bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-cyan-400 to-yellow-400 rounded-full"
              initial={{ width: '0%' }}
              animate={{ width: `${Math.min((dotsEaten / 15) * 100, 100)}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
          <span className="text-gray-400 text-sm">{Math.min(Math.round((dotsEaten / 15) * 100), 100)}%</span>
        </div>
      </motion.div>

      <style jsx>{`
        .grid-background {
          background-image: 
            linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px);
          background-size: 50px 50px;
          width: 100%;
          height: 100%;
        }
      `}</style>
    </motion.div>
  );
}