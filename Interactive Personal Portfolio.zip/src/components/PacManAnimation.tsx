import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

interface PacManAnimationProps {
  isDarkMode?: boolean;
}

export function PacManAnimation({ isDarkMode = true }: PacManAnimationProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [score, setScore] = useState(0);

  // Create dots for Pac-Man to eat
  const dots = Array.from({ length: 20 }, (_, i) => i);
  
  // Ghost colors
  const ghostColors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4'];

  useEffect(() => {
    // Hide animation on mobile for better performance
    const checkMobile = () => {
      setIsVisible(window.innerWidth > 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    // Score counter
    const scoreTimer = setInterval(() => {
      setScore(prev => (prev + 10) % 1000);
    }, 800);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
      clearInterval(scoreTimer);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <div className="relative w-full z-[1] pointer-events-none overflow-hidden h-24 my-8">
      {/* Score Display */}
      <motion.div
        className={`absolute top-4 right-8 text-xs font-mono opacity-40 ${
          isDarkMode ? 'text-yellow-400' : 'text-yellow-600'
        }`}
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 0.4, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        SCORE: {score.toString().padStart(4, '0')}
      </motion.div>

      {/* Dots Path */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-between items-center px-8">
        {dots.map((_, index) => (
          <motion.div
            key={index}
            className="w-2 h-2 bg-yellow-400 rounded-full opacity-60 shadow-sm shadow-yellow-400/50"
            initial={{ opacity: 0.6, scale: 1 }}
            animate={{ 
              opacity: [0.6, 0, 0.6],
              scale: [1, 0.3, 1],
              rotate: [0, 180, 360]
            }}
            transition={{
              duration: 0.4,
              delay: index * 0.6, // Stagger the disappearing effect
              repeat: Infinity,
              repeatDelay: 11 // Total animation cycle time
            }}
          />
        ))}
      </div>

      {/* Pac-Man */}
      <motion.div
        className="absolute bottom-6 w-8 h-8"
        initial={{ x: -60 }}
        animate={{ x: 'calc(100vw + 60px)' }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "linear",
          repeatDelay: 0
        }}
      >
        <motion.div
          className="w-8 h-8 bg-gradient-to-br from-yellow-300 to-yellow-500 rounded-full relative shadow-lg shadow-yellow-400/30"
          animate={{
            clipPath: [
              'polygon(0% 0%, 100% 0%, 70% 50%, 100% 100%, 0% 100%)',
              'polygon(0% 0%, 100% 0%, 100% 50%, 100% 100%, 0% 100%)',
              'polygon(0% 0%, 100% 0%, 70% 50%, 100% 100%, 0% 100%)'
            ]
          }}
          transition={{
            duration: 0.4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        
        {/* Pac-Man Eye */}
        <div className="absolute top-1.5 right-2 w-1.5 h-1.5 bg-black rounded-full" />
        
        {/* Power Pellet Effect */}
        <motion.div
          className="absolute -top-1 -right-1 w-2 h-2 bg-white rounded-full opacity-0"
          animate={{
            opacity: [0, 1, 0],
            scale: [0.5, 1.2, 0.5]
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            delay: 2
          }}
        />
      </motion.div>

      {/* Ghosts */}
      {[0, 1, 2].map((ghostIndex) => (
        <motion.div
          key={ghostIndex}
          className="absolute bottom-6 w-6 h-8"
          initial={{ x: -100 - (ghostIndex * 40) }}
          animate={{ x: 'calc(100vw + 100px)' }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "linear",
            delay: 1 + ghostIndex * 0.3,
            repeatDelay: 0
          }}
        >
          {/* Ghost Body */}
          <div 
            className="w-6 h-6 rounded-t-full relative"
            style={{ backgroundColor: ghostColors[ghostIndex] }}
          >
            {/* Ghost Eyes */}
            <div className="absolute top-1.5 left-1 w-1 h-1 bg-white rounded-full" />
            <div className="absolute top-1.5 right-1 w-1 h-1 bg-white rounded-full" />
            <div className="absolute top-2 left-1.5 w-0.5 h-0.5 bg-black rounded-full" />
            <div className="absolute top-2 right-1.5 w-0.5 h-0.5 bg-black rounded-full" />
          </div>
          
          {/* Ghost Bottom (wavy) */}
          <div className="relative">
            <div 
              className="w-6 h-2 relative"
              style={{ backgroundColor: ghostColors[ghostIndex] }}
            >
              <div className="absolute bottom-0 left-0 w-1.5 h-1.5 bg-transparent rounded-full"
                   style={{ boxShadow: `0 0 0 2px ${ghostColors[ghostIndex]}` }} />
              <div className="absolute bottom-0 left-1.5 w-1.5 h-1.5 bg-transparent rounded-full"
                   style={{ boxShadow: `0 0 0 2px ${ghostColors[ghostIndex]}` }} />
              <div className="absolute bottom-0 right-1.5 w-1.5 h-1.5 bg-transparent rounded-full"
                   style={{ boxShadow: `0 0 0 2px ${ghostColors[ghostIndex]}` }} />
              <div className="absolute bottom-0 right-0 w-1.5 h-1.5 bg-transparent rounded-full"
                   style={{ boxShadow: `0 0 0 2px ${ghostColors[ghostIndex]}` }} />
            </div>
          </div>
        </motion.div>
      ))}

      {/* Fun Messages */}
      <motion.div
        className={`absolute bottom-16 left-8 text-xs font-mono opacity-30 ${
          isDarkMode ? 'text-cyan-400' : 'text-cyan-600'
        }`}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.3, 0] }}
        transition={{
          duration: 3,
          repeat: Infinity,
          repeatDelay: 9
        }}
      >
        {"< RETRO_MODE />"}
      </motion.div>
      
      <motion.div
        className={`absolute bottom-16 right-24 text-xs font-mono opacity-30 ${
          isDarkMode ? 'text-pink-400' : 'text-pink-600'
        }`}
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.3, 0] }}
        transition={{
          duration: 3,
          repeat: Infinity,
          repeatDelay: 6,
          delay: 6
        }}
      >
        CODING.LEVEL++
      </motion.div>
    </div>
  );
}